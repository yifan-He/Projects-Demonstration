using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewGame : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        PlayerMovement.count = 0;
    }


}

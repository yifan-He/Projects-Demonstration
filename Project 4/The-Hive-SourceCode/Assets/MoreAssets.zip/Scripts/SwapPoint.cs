using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwapPoint : MonoBehaviour
{
    public int swapNumber;//data

}
